# models.py placeholder


from django.contrib.auth.models import User
from django.db import models

class Workout(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    workout_type = models.CharField(max_length=100)
    duration_minutes = models.IntegerField()
    calories_burned = models.FloatField()

    def __str__(self):
        return f"{self.user.username} - {self.workout_type} on {self.date}"

class DailyStats(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    steps = models.IntegerField(default=0)
    calories = models.FloatField(default=0)

    def __str__(self):
        return f"{self.user.username} - Stats on {self.date}"

class Goal(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    description = models.CharField(max_length=255)
    target = models.FloatField()
    progress = models.FloatField(default=0)
    date_set = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - Goal: {self.description}"
