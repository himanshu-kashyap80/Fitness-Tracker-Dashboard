from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import RegisterForm, UpdateProfileForm, WorkoutForm, DailyStatsForm, GoalForm
from .models import Workout, DailyStats, Goal

def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = RegisterForm()
    return render(request, 'accounts/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
        else:
            return render(request, 'accounts/login.html', {'error': 'Invalid username or password'})
    return render(request, 'accounts/login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def profile_view(request):
    if request.method == 'POST':
        form = UpdateProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = UpdateProfileForm(instance=request.user)
    return render(request, 'accounts/profile.html', {'form': form})

@login_required
def dashboard(request):

    workouts = Workout.objects.filter(user=request.user).order_by('-date', '-id')[:5]
    stats = DailyStats.objects.filter(user=request.user).order_by('-date', '-id').first()
    goals = Goal.objects.filter(user=request.user).order_by('-date_set', '-id')
    context = {
        'workouts': workouts,
        'stats': stats,
        'goals': goals,
    }
    return render(request, 'accounts/dashboard.html', context)

@login_required
def add_workout(request):
    if request.method == 'POST':
        form = WorkoutForm(request.POST)
        if form.is_valid():
            workout = form.save(commit=False)
            workout.user = request.user  
            print("DEBUG: Saving workout for user id =>", request.user.id)  
            workout.save()
            return redirect('dashboard')
    else:
        form = WorkoutForm()
    return render(request, 'accounts/add_workout.html', {'form': form})

@login_required
def add_stats(request):
    if request.method == 'POST':
        form = DailyStatsForm(request.POST)
        if form.is_valid():
            stat = form.save(commit=False)
            stat.user = request.user  
            stat.save()
            return redirect('dashboard')
    else:
        form = DailyStatsForm()
    return render(request, 'accounts/add_stats.html', {'form': form})

@login_required
def set_goal(request):
    if request.method == 'POST':
        form = GoalForm(request.POST)
        if form.is_valid():
            goal = form.save(commit=False)
            goal.user = request.user  
            goal.save()
            return redirect('dashboard')
    else:
        form = GoalForm()
    return render(request, 'accounts/set_goal.html', {'form': form})
